=== Incorrect Datetime Bug Fix ===
Contributors: eddiemoya
Donate link: http://eddiemoya.com
Tags: mysql, sql, sql_mode, no_zero_date, no_zero_in_date, bug, timestamp
Requires at least: Lowest version unknown
Tested up to: 3.2.1
Stable tag: trunk

Fixes sql_modes that cause error: "Incorrect datetime value: '0000-00-00 00:00:00' for column 'post_date_gmt' at row 1"

== Description ==
This plugin was create to work around a problem that -I have to assume- only occurs after a database migration, where certain configurations in MySQL lead to several odd symtoms including but not limited to:

* Loss of ability to create new posts
* Loss of ability to update posts
* Errors regarding invalid timestamps
* Admin interface reverts to lowest permissions ex:‘Publish’ button says ‘Submit Draft’.

In addition, this problem is often accompanied by an error like the following:


<code>WordPress database error: [Incorrect datetime value: '0000-00-00 00:00:00' for column 'post_date_gmt' at row 1]
INSERT INTO `mg_posts` (`post_author`,`post_date`,`post_date_gmt`,`post_content`,`post_content_filtered`,`post_title`,`post_excerpt`,`post_status`,`post_type`,`comment_status`,`ping_status`,`post_password`,`post_name`,`to_ping`,`pinged`,`post_modified`,`post_modified_gmt`,`post_parent`,`menu_order`,`guid`) VALUES (’1′,’2011-08-23 03:32:43′,’0000-00-00 00:00:00′,”,”,’Auto Draft’,”,’auto-draft’,'post’,'closed’,'open’,”,”,”,”,’2011-08-23 03:32:43′,’0000-00-00 00:00:00′,’0′,’0′,”)</code>


The inability to pass zero dates breaks the ability to actually create a new post, but it also seems to have the odd secondary effect of confusing the heck out of nonces (noces are a security feature), probably because they too rely on timestamps.

This plugin strips out the sql_modes listed below from @@SESSION, thereby eliminating the problem while only effecting database sessions WordPress starts and not the whole database.


== Explanation and history of the problem ==

The cause of this problem stems from an old (soon to be deprecated) odd behavior/feature of MySQL which WordPress came to depend on. My understanding is that it stems from problems in MySQL with regard to using the MySQL NOW() function in some contexts – so as a workaround it was decided that if a date of all zeros was entered on a column that was set as NOT NULL, then that date would not be rejected, but instead would be converted to the current date – to mimic NOW().

Subsequently this method was marginalized as generally a bad idea – and now values exist for a setting called sql_mode, which turn this behavior off and force errors when a null value is passed to a NOT NULL field. In many cases when there is an actual DBA in charge of the database, they will assign these values to the production database to force what outside of MySQL would be normal SQL behavior.

There are 3 sql_modes which will trigger the error by disabling the ability to enter zero dates.

* NO_ZERO_DATE
* NO_ZERO_IN_DATE
* TRADITIONAL

It’s worth mentioning that the ALLOW_INVALID_DATES mode does NOT solve the problem, even though by the name of it, it would seem that it might.


== The solution ==

This plugin solves the problem with minimal effect to the database environment. All this plugin does it check to see if the sql_modes in question are set, and if they are, it removes them.

Importantly, this plugin changes @@SESSION.sql_mode and not @@GLOBAL.sql_mode. By changing sql_mode via the session, it only takes effect on each specific connections WordPress makes with the database rather than changing it for the entire database permanently - as such this will have no effect whatsoever on any applications that might happen to be using the same database.


== Other manifestations, alternative solutions. ==

WARNING: Whenever applicable, consult your DBA before making any changes to production databases.

This problem may (I have no idea) in fact be more common during installation. The errors are different, and although I have seen them, I do not have them handy at this time. In any case, if the sql_modes are set during installation – the process will fail from the start – because of this, it is my presumption that anyone encountering the errors as described above – has probably recently migrated to a new database, or perhaps recently acquired an enthusiastic new DBA who has made some changes.

This plugin DOES NOT FIX this problem for those encountering during installation – thats impossible because WordPress ignores all plugins during installation – so there is no way to hack around it via plugin and fix it before installation occurs.

If you are encountering this problem during installation you will need to find an alternative way to remove the modes. If this is a production environment this may require the cooperation of a DBA who may not like the idea. If met with resistance, I suggest the asking for the modes to be temporarily removed for installation, and then set back after its dont – at which point this plugin will handle the problem from then on.

If your encountering this locally, or on a environment whose database you have access to modify, you will want to make as few changes as possible, so go to whatever interface you use (command line, phpMyAdmin, whatever) and run this line of SQL:


`SELECT @@GLOBAL.sql_mode;`


This will show you all the sql modes currently defined. Copy all them them but if you have NO_ZERO_DATE, NO_ZERO_IN_DATE, or TRADITIONAL remove them. Then update sql_mode with the remaining modes as such:


`SET @@GLOBAL.sql_mode = "STRICT_TRANS_TABLES,STRICT_ALL_TABLES,ERROR_FOR_DIVISION_BY_ZERO";`


Please don’t simply use the sql_mode definition I have shown above, this is only an example – be sure to use the modes from your database configuration. Remember to keep everything together NO SPACES ALLOWED in the definition.

Finally, if your just working locally and don’t care about these sql_modes, you can just clear them all.


`SET @@GLOBAL.sql_mode = "";`


This will do the trick but is absolutely not recommended as a fix for production sites that might share environments.

Irrelevant Note: I struggled with naming this plugin, and settled on the terminology seen in the error message.



== Installation ==

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress


= Will this fix sql_mode during installation? =

No, plugins are not loaded during installation. For alternative solutions see 
"Other manifestations, alternative solutions" on the plugin home page


= Will this effect other applications that might run on the same database, and depend on these sql_mode settings? =

No, it uses @@SESSION.sql_mode to change the settings for each WordPress session individually.

= How do I undo what this plugin does? =

Just turn off the plugin - because it uses @@SESSION, the changes wont persist. 

If you've made other modifications explained by me, you will have to run similar SQL commands to apply the old settings.